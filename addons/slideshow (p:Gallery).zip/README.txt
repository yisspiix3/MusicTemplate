A Pen created at CodePen.io. You can find this one at http://codepen.io/leemark/pen/Ddgsx.

 Also supports swiping on touch devices. A vanilla JS (no-jQuery) version can be found here: http://codepen.io/leemark/pen/DLgbr 

Step-by-step blog post here: http://themarklee.com/2013/12/26/simple-diy-responsive-slideshow-made-html5-css3-javascript/