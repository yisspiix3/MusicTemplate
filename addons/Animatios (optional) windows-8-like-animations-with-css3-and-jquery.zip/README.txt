A Pen created at CodePen.io. You can find this one at http://codepen.io/SaraSoueidan/pen/sBELl.

 UPDATED DEMO FOR MY BLOG POST TUTORIAL 
How to Create Windows-8-like Animations with CSS3 and jQuery
http://blog.sarasoueidan.com/windows8-animations

BEST VIEWED IN WEBKIT BROWSERS and FULL VIEW MODE.